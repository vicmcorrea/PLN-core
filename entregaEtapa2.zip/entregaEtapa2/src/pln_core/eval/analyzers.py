

from __future__ import annotations

from pln_core.eval.registry import Registry
from pln_core.lexicon import OPLEXICON_LEXICON_SOURCE, load_lexicon
from pln_core.pipeline import SymbolicSentimentAnalyzer
from pln_core.sentilex import load_sentilex_flex
from pln_core.tokenizers import tokenize_spacy_pt_lemmas
from pln_core.twitter_lexicon import load_twitter_extras
from pln_core.twitter_norm import tokenize_tweet, tokenize_tweet_lemma

ANALYZER_REGISTRY: Registry[SymbolicSentimentAnalyzer] = Registry("analyzer")


def create_analyzer(name: str, **kwargs: object) -> SymbolicSentimentAnalyzer:


    return ANALYZER_REGISTRY.create(name, **kwargs)


@ANALYZER_REGISTRY.register("seed")
def _build_seed_analyzer(**kwargs: object) -> SymbolicSentimentAnalyzer:


    return SymbolicSentimentAnalyzer(**kwargs)                          


@ANALYZER_REGISTRY.register("oplexicon")
def _build_oplexicon_analyzer(**kwargs: object) -> SymbolicSentimentAnalyzer:







    lexicon = load_lexicon(source=OPLEXICON_LEXICON_SOURCE)
    return SymbolicSentimentAnalyzer(
        lexicon=lexicon,
        tokenizer=tokenize_spacy_pt_lemmas,
        **kwargs,                          
    )


@ANALYZER_REGISTRY.register("oplexicon_regex")
def _build_oplexicon_regex_analyzer(**kwargs: object) -> SymbolicSentimentAnalyzer:


    lexicon = load_lexicon(source=OPLEXICON_LEXICON_SOURCE)
    return SymbolicSentimentAnalyzer(lexicon=lexicon, **kwargs)                          


def _merge_lexicons(*sources: dict[str, float]) -> dict[str, float]:


    merged: dict[str, float] = {}
    for source in sources:
        merged.update(source)
    return merged


@ANALYZER_REGISTRY.register("oplexicon_tweet")
def _build_oplexicon_tweet_analyzer(
    positive_threshold: float = 0.5,
    negative_threshold: float = -0.5,
    **kwargs: object,
) -> SymbolicSentimentAnalyzer:


















    lexicon = _merge_lexicons(
        load_lexicon(source=OPLEXICON_LEXICON_SOURCE),
        load_twitter_extras(),
    )
    return SymbolicSentimentAnalyzer(
        lexicon=lexicon,
        tokenizer=tokenize_tweet,
        positive_threshold=positive_threshold,
        negative_threshold=negative_threshold,
        **kwargs,                          
    )


@ANALYZER_REGISTRY.register("oplexicon_tweet_plus")
def _build_oplexicon_tweet_plus_analyzer(
    positive_threshold: float = 0.5,
    negative_threshold: float = -0.5,
    sentilex_weight: float = 0.6,
    **kwargs: object,
) -> SymbolicSentimentAnalyzer:















    sentilex = {
        token: score * sentilex_weight
        for token, score in load_sentilex_flex().items()
    }
    lexicon = _merge_lexicons(
        sentilex,
        load_lexicon(source=OPLEXICON_LEXICON_SOURCE),
        load_twitter_extras(),
    )
    return SymbolicSentimentAnalyzer(
        lexicon=lexicon,
        tokenizer=tokenize_tweet,
        positive_threshold=positive_threshold,
        negative_threshold=negative_threshold,
        **kwargs,                          
    )


@ANALYZER_REGISTRY.register("oplexicon_tweet_lemma")
def _build_oplexicon_tweet_lemma_analyzer(
    positive_threshold: float = 0.5,
    negative_threshold: float = -0.5,
    **kwargs: object,
) -> SymbolicSentimentAnalyzer:









    lexicon = _merge_lexicons(
        load_lexicon(source=OPLEXICON_LEXICON_SOURCE),
        load_twitter_extras(),
    )
    return SymbolicSentimentAnalyzer(
        lexicon=lexicon,
        tokenizer=tokenize_tweet_lemma,
        positive_threshold=positive_threshold,
        negative_threshold=negative_threshold,
        **kwargs,                          
    )


class _MajorityAnalyzer:


    def __init__(self, label: str = "positive") -> None:
        from pln_core.pipeline import AnalysisResult

        self._label = label
        self._result_cls = AnalysisResult

    def analyze(self, text: str):
        return self._result_cls(
            text=text,
            normalized_text=text,
            tokens=(),
            score=0.0,
            label=self._label,
            matched_terms=(),
        )


@ANALYZER_REGISTRY.register("majority")
def _build_majority_analyzer(label: str = "positive"):


    return _MajorityAnalyzer(label=label)
