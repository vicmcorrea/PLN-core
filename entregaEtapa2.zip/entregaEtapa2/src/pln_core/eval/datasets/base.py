

from __future__ import annotations

import random
from collections.abc import Iterable, Sequence
from dataclasses import dataclass

VALID_LABELS = ("positive", "negative", "neutral")


@dataclass(frozen=True, slots=True)
class EvalExample:


    text: str
    label: str

    def __post_init__(self) -> None:
        if self.label not in VALID_LABELS:
            raise ValueError(
                f"invalid label '{self.label}' (expected one of {VALID_LABELS})"
            )


@dataclass(frozen=True, slots=True)
class EvalDataset:


    name: str
    description: str
    examples: Sequence[EvalExample]

    def __len__(self) -> int:
        return len(self.examples)


def rating_to_3class(rating: int | str | None) -> str | None:





    try:
        score = int(rating)                          
    except (TypeError, ValueError):
        return None
    if score in (1, 2):
        return "negative"
    if score == 3:
        return "neutral"
    if score in (4, 5):
        return "positive"
    return None


def stratified_sample(
    examples: Iterable[EvalExample],
    per_class: int,
    seed: int,
) -> list[EvalExample]:






    by_label: dict[str, list[EvalExample]] = {}
    for example in examples:
        by_label.setdefault(example.label, []).append(example)

    rng = random.Random(seed)
    selected: list[EvalExample] = []
    for items in by_label.values():
        rng.shuffle(items)
        selected.extend(items[:per_class])
    rng.shuffle(selected)
    return selected
