














from __future__ import annotations

import re

from pln_core.text_utils import (
    MENTION_PATTERN,
    URL_PATTERN,
    WHITESPACE_PATTERN,
    fold_text,
)

WORD_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")
EMOJI_TOKEN_PATTERN = re.compile(
    r"["
    r"\U0001F300-\U0001FAFF"                                             
    r"\U00002600-\U000027BF"                            
    r"\u2700-\u27BF"                      
    r"\u2300-\u23FF"                            
    r"]"
    r"\uFE0F?",
    flags=re.UNICODE,
)
HASHTAG_PATTERN = re.compile(r"#(\w+)")
LAUGH_K_PATTERN = re.compile(r"k{3,}", flags=re.IGNORECASE)
LAUGH_K_SHORT_PATTERN = re.compile(r"\bkk\b", flags=re.IGNORECASE)
LAUGH_HA_PATTERN = re.compile(r"\b(?:ha){2,}\b", flags=re.IGNORECASE)
LAUGH_HE_PATTERN = re.compile(r"\b(?:he){2,}\b", flags=re.IGNORECASE)
LAUGH_RS_PATTERN = re.compile(r"\b(?:rs){2,}\b", flags=re.IGNORECASE)
REPEAT_3_PLUS_PATTERN = re.compile(r"(.)\1{2,}")
CAMEL_SPLIT_PATTERN = re.compile(r"(?<=[a-z])(?=[A-Z])")


def _split_hashtag(match: re.Match[str]) -> str:
    raw = match.group(1)
    if any(ch.isupper() for ch in raw[1:]):
        parts = CAMEL_SPLIT_PATTERN.split(raw)
        return " " + " ".join(parts) + " "
    return " " + raw + " "


def normalize_tweet(text: str) -> str:

















    cleaned = URL_PATTERN.sub(" ", text)
    cleaned = MENTION_PATTERN.sub(" ", cleaned)
    cleaned = HASHTAG_PATTERN.sub(_split_hashtag, cleaned)
    cleaned = LAUGH_K_PATTERN.sub("kkk", cleaned)
    cleaned = LAUGH_K_SHORT_PATTERN.sub("kkk", cleaned)
    cleaned = LAUGH_HA_PATTERN.sub("haha", cleaned)
    cleaned = LAUGH_HE_PATTERN.sub("hehe", cleaned)
    cleaned = LAUGH_RS_PATTERN.sub("rsrs", cleaned)
    cleaned = REPEAT_3_PLUS_PATTERN.sub(r"\1", cleaned)
    cleaned = WHITESPACE_PATTERN.sub(" ", cleaned).strip()
    return cleaned


def tokenize_tweet(text: str) -> list[str]:







    normalized = normalize_tweet(text)
    folded = fold_text(normalized)
    pieces: list[tuple[int, str]] = []
    for match in WORD_TOKEN_PATTERN.finditer(folded):
        pieces.append((match.start(), match.group(0)))
    for match in EMOJI_TOKEN_PATTERN.finditer(normalized):
        pieces.append((match.start(), match.group(0)))
    pieces.sort(key=lambda item: item[0])
    return [token for _, token in pieces]


def tokenize_tweet_lemma(text: str) -> list[str]:














    from pln_core.tokenizers import _build_spacy_lemmatizer

    normalized = normalize_tweet(text)
    emoji_positions = [
        (match.start(), match.group(0))
        for match in EMOJI_TOKEN_PATTERN.finditer(normalized)
    ]
    text_without_emoji = EMOJI_TOKEN_PATTERN.sub(" ", normalized)
    doc = _build_spacy_lemmatizer()(text_without_emoji)
    tokens: list[tuple[int, str]] = []
    for token in doc:
        lemma = fold_text(token.lemma_ or token.text)
        if not lemma.strip():
            continue
        if WORD_TOKEN_PATTERN.fullmatch(lemma) is None:
            continue
        tokens.append((token.idx, lemma))
    tokens.extend(emoji_positions)
    tokens.sort(key=lambda item: item[0])
    return [token for _, token in tokens]
