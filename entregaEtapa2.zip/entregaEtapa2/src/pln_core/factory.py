






from __future__ import annotations

from pln_core.eval.analyzers import create_analyzer
from pln_core.pipeline import SymbolicSentimentAnalyzer

PRODUCTION_ANALYZER_NAME = "oplexicon_regex"
PRODUCTION_ANALYZER_LABEL = "OpLexicon v3.0 + regex tokenizer"


def build_production_analyzer() -> SymbolicSentimentAnalyzer:


    return create_analyzer(PRODUCTION_ANALYZER_NAME)
