















from __future__ import annotations

import re
from pathlib import Path

from pln_core.text_utils import fold_text

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SENTILEX_FLEX_PATH = PROJECT_ROOT / "data" / "external" / "SentiLex-flex-PT02.txt"

POL_PATTERN = re.compile(r"POL:N[01]=(-?\d+)")


def load_sentilex_flex(path: str | Path | None = None) -> dict[str, float]:







    target = Path(path) if path else SENTILEX_FLEX_PATH
    if not target.exists():
        raise FileNotFoundError(
            f"SentiLex flex file not found at {target}. Download it from "
            "https://github.com/sillasgonzaga/lexiconPT (data-raw/)."
        )

    raw: dict[str, list[float]] = {}
    with target.open("r", encoding="latin-1") as handle:
        for line in handle:
            if "," not in line:
                continue
            surface, rest = line.split(",", 1)
            match = POL_PATTERN.search(rest)
            if not match:
                continue
            polarity = float(match.group(1))
            if polarity == 0:
                continue
            key = fold_text(surface.strip())
            if not key:
                continue
            raw.setdefault(key, []).append(polarity)

    return {token: sum(scores) / len(scores) for token, scores in raw.items()}
