


















import csv
from importlib import resources

from pln_core.text_utils import fold_text


def load_twitter_extras() -> dict[str, float]:







    path = resources.files("pln_core.data").joinpath("slang_emoji_ptbr.tsv")
    extras: dict[str, float] = {}
    with path.open("r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        for row in reader:
            token = (row.get("token") or "").strip()
            if not token:
                continue
            try:
                score = float(row["score"])
            except (KeyError, ValueError):
                continue
            key = token if _is_emoji_token(token) else fold_text(token)
            extras[key] = score
    return extras


def _is_emoji_token(token: str) -> bool:


    return not any(ch.isascii() and ch.isalnum() for ch in token)
