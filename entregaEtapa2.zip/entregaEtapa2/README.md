# Entrega Etapa 2

## Ambiente

```bash
uv sync
```

## Corpus Kaggle

Os CSVs do corpus nao estao incluidos neste arquivo de entrega. Configure suas credenciais do Kaggle em `~/.kaggle/kaggle.json` ou por variaveis de ambiente e rode o comando abaixo.

```bash
uv run python scripts/download_kaggle_dataset.py
```

O script cria `data/raw/portuguese-tweets-for-sentiment-analysis/` e valida os arquivos `TrainingDatasets/Train3Classes.csv` e `TestDatasets/Test3classes.csv`.

## Testes

```bash
uv run pytest
```

## Aplicacao

```bash
uv run streamlit run streamlit_app.py
```

## Reproduzir Etapa 1

```bash
uv run python etapas/etapa1_simbolica/pipelines/run_symbolic_benchmark_suite.py 'text_treatments=[raw,strip_emoticons_urls,strip_social_source_cues]'
```

## Reproduzir Etapa 2 classica

```bash
uv run python etapas/etapa2_subsimbolica/pipelines/run_classical_benchmark_suite.py text_treatment=strip_emoticons_urls
uv run python etapas/etapa2_subsimbolica/pipelines/run_leakage_diagnostics.py
```

## Reproduzir transformer

```bash
uv run --extra transformers python etapas/etapa2_subsimbolica/pipelines/run_transformer_benchmark.py model=albertina_ptbr_100m text_treatment=strip_emoticons_urls train_per_class=1000
```
